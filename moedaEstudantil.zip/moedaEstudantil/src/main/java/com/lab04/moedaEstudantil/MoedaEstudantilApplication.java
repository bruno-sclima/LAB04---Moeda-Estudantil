package com.lab04.moedaEstudantil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoedaEstudantilApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoedaEstudantilApplication.class, args);
	}

}
