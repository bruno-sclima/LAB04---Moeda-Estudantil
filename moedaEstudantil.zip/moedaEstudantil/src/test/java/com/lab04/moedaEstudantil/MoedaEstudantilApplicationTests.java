package com.lab04.moedaEstudantil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoedaEstudantilApplicationTests {

	@Test
	void contextLoads() {
	}

}
